// package com.examly.springapp.controller;

// import com.examly.springapp.entity.*;
// import com.examly.springapp.service.ApplicationService;
// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.http.*;
// import org.springframework.web.bind.annotation.*;

// import java.util.*;

// @RestController
// @RequestMapping("/api/applications")
// public class ApplicationController {

//     @Autowired
//     private ApplicationService applicationService;

//     // === Submit Application ===
//     @PostMapping
//     public ResponseEntity<?> submitApplication(@RequestBody CreateApplicationRequest request) {
//         try {
//             Application app = applicationService.createApplication(request.getStudentId(),
//                     request.getScholarshipId(),
//                     request.getDocuments());
//             return new ResponseEntity<>(app, HttpStatus.CREATED);
//         } catch (IllegalArgumentException e) {
//             return ResponseEntity.badRequest().body(new ErrorResponse(e.getMessage()));
//         }
//     }

//     // === Get All Applications or by Status ===
//     @GetMapping
//     public ResponseEntity<?> getAllApplications(@RequestParam(required = false) String status) {
//         if (status != null) {
//             try {
//                 ApplicationStatus statusEnum = ApplicationStatus.valueOf(status.toUpperCase());
//                 return ResponseEntity.ok(applicationService.getApplicationsByStatus(statusEnum));
//             } catch (IllegalArgumentException e) {
//                 return ResponseEntity.badRequest()
//                         .body(new ErrorResponse("Status must be PENDING, APPROVED, or REJECTED"));
//             }
//         } else {
//             return ResponseEntity.ok(applicationService.getAllApplications());
//         }
//     }

//     // === Get Application by ID ===
//     @GetMapping("/{id}")
//     public ResponseEntity<?> getApplicationById(@PathVariable Long id) {
//         Optional<Application> app = applicationService.getApplicationById(id);
//         if (app.isPresent()) {
//             return ResponseEntity.ok(app.get());
//         } else {
//             return ResponseEntity.status(HttpStatus.NOT_FOUND)
//                     .body(new ErrorResponse("Application not found"));
//         }
//     }

//     // === Update Application Status ===
//     // @PutMapping("/{id}/status")
//     // public ResponseEntity<?> updateApplicationStatus(
//     // @PathVariable Long id,
//     // @RequestBody UpdateApplicationStatusRequest request) {
//     // ApplicationStatus statusEnum;
//     // try {
//     // statusEnum = ApplicationStatus.valueOf(request.getStatus().toUpperCase());
//     // } catch (IllegalArgumentException e) {
//     // return ResponseEntity.badRequest()
//     // .body(new ErrorResponse("Status must be PENDING, APPROVED, or REJECTED"));
//     // }

//     // try {
//     // Application updated = applicationService.updateApplicationStatus(id,
//     // statusEnum, request.getComments());
//     // return ResponseEntity.ok(updated);
//     // } catch (IllegalArgumentException e) {
//     // return ResponseEntity.status(HttpStatus.NOT_FOUND)
//     // .body(new ErrorResponse(e.getMessage()));
//     // }
//     // }
//     @PutMapping("/{id}/status")
//     public ResponseEntity<?> updateApplicationStatus(
//             @PathVariable Long id,
//             @RequestBody UpdateApplicationStatusRequest request) {
//         ApplicationStatus statusEnum;
//         try {
//             statusEnum = ApplicationStatus.valueOf(request.getStatus().toUpperCase());
//         } catch (IllegalArgumentException e) {
//             return ResponseEntity.badRequest()
//                     .body(new ErrorResponse("Status must be PENDING, APPROVED, or REJECTED"));
//         }

//         try {
//             Application updated = applicationService.updateApplicationStatus(id, statusEnum, request.getComments());

//             // return only status + comments
//             Map<String, Object> response = new HashMap<>();
//             response.put("status", updated.getStatus().toString());
//             response.put("comments", updated.getComments());

//             return ResponseEntity.ok(response);
//         } catch (IllegalArgumentException e) {
//             return ResponseEntity.status(HttpStatus.NOT_FOUND)
//                     .body(new ErrorResponse(e.getMessage()));
//         }
//     }

//     // === Request DTOs ===
//     public static class CreateApplicationRequest {
//         private Long studentId;
//         private Long scholarshipId;
//         private String documents;

//         public Long getStudentId() {
//             return studentId;
//         }

//         public void setStudentId(Long studentId) {
//             this.studentId = studentId;
//         }

//         public Long getScholarshipId() {
//             return scholarshipId;
//         }

//         public void setScholarshipId(Long scholarshipId) {
//             this.scholarshipId = scholarshipId;
//         }

//         public String getDocuments() {
//             return documents;
//         }

//         public void setDocuments(String documents) {
//             this.documents = documents;
//         }
//     }

//     public static class UpdateApplicationStatusRequest {
//         private String status;
//         private String comments;

//         public String getStatus() {
//             return status;
//         }

//         public void setStatus(String status) {
//             this.status = status;
//         }

//         public String getComments() {
//             return comments;
//         }

//         public void setComments(String comments) {
//             this.comments = comments;
//         }
//     }

//     // === Error Response DTO ===
//     public static class ErrorResponse {
//         private String message;

//         public ErrorResponse(String message) {
//             this.message = message;
//         }

//         public String getMessage() {
//             return message;
//         }

//         public void setMessage(String message) {
//             this.message = message;
//         }
//     }
// }
package com.examly.springapp.controller;
import com.examly.springapp.entity.Application;
import com.examly.springapp.entity.ApplicationStatus;
import com.examly.springapp.service.ApplicationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/applications")
public class ApplicationController {

    @Autowired
    private ApplicationService applicationService;
    @PostMapping
    public ResponseEntity<?> submitApplication(@RequestBody CreateApplicationRequest request) {
        try {
            Application application = applicationService.createApplication(request.getStudentId(),
                    request.getScholarshipId(),
                    request.getDocuments());
            return ResponseEntity.status(HttpStatus.CREATED).body(application);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(Map.of("message", e.getMessage()));
        }
    }

    @GetMapping
    public ResponseEntity<List<Application>> getAllApplications(@RequestParam(required = false) String status) {
        if (status != null) {
            try {
                ApplicationStatus applicationStatus = ApplicationStatus.valueOf(status.toUpperCase());
                List<Application> applications = applicationService.getApplicationsByStatus(applicationStatus);
                return ResponseEntity.ok(applications);
            } catch (IllegalArgumentException e) {
                return ResponseEntity.ok(List.of());
            }
        }
        return ResponseEntity.ok(applicationService.getAllApplications());
    }

    @PutMapping("/{id}/status")
    public ResponseEntity<?> updateApplicationStatus(@PathVariable Long id,
            @RequestBody UpdateApplicationStatusRequest request) {
        try {
            if (!isValidStatus(request.getStatus())) {
                return ResponseEntity.badRequest()
                        .body(Map.of("message", "Status must be PENDING, APPROVED, or REJECTED"));
            }

            ApplicationStatus status = ApplicationStatus.valueOf(request.getStatus().toUpperCase());
            Application updatedApplication = applicationService.updateApplicationStatus(id, status,
                    request.getComments());

           
            Map<String, Object> response = new HashMap<>();
            response.put("id", updatedApplication.getId());
            response.put("status", updatedApplication.getStatus().toString());
            response.put("comments", updatedApplication.getComments());

            return ResponseEntity.ok(response);
        } catch (IllegalArgumentException e) {
            if (e.getMessage().contains("Application not found")) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of("message", "Application not found"));
            }
            return ResponseEntity.badRequest().body(Map.of("message", e.getMessage()));
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getApplicationById(@PathVariable Long id) {
        Optional<Application> application = applicationService.getApplicationById(id);
        if (application.isPresent()) {
            return ResponseEntity.ok(application.get());
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of("message", "Application not found"));
        }
    }

    private boolean isValidStatus(String status) {
        if (status == null || status.trim().isEmpty())
            return false;
        return status.equalsIgnoreCase("PENDING") ||
                status.equalsIgnoreCase("APPROVED") ||
                status.equalsIgnoreCase("REJECTED");
    }
    
    public static class CreateApplicationRequest {
        private Long studentId;
        private Long scholarshipId;
        private String documents;

        public Long getStudentId() {
            return studentId;
        }

        public void setStudentId(Long studentId) {
            this.studentId = studentId;
        }

        public Long getScholarshipId() {
            return scholarshipId;
        }

        public void setScholarshipId(Long scholarshipId) {
            this.scholarshipId = scholarshipId;
        }

        public String getDocuments() {
            return documents;
        }

        public void setDocuments(String documents) {
            this.documents = documents;
        }
    }

    public static class UpdateApplicationStatusRequest {
        private String status;
        private String comments;

        public String getStatus() {
            return status;
        }

        public void setStatus(String status) {
            this.status = status;
        }

        public String getComments() {
            return comments;
        }

        public void setComments(String comments) {
            this.comments = comments;
        }
    }
}
