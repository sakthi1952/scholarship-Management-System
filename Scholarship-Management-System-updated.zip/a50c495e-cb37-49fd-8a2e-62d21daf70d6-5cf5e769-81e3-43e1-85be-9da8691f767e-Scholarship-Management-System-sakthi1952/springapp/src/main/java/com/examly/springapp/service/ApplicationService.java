package com.examly.springapp.service;

import com.examly.springapp.entity.*;
import com.examly.springapp.repository.ApplicationRepository;
import com.examly.springapp.repository.ScholarshipRepository;
import com.examly.springapp.repository.StudentRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
public class ApplicationService {

    @Autowired
    private ApplicationRepository applicationRepository;

    @Autowired
    private StudentRepository studentRepository;

    @Autowired
    private ScholarshipRepository scholarshipRepository;

    public Application createApplication(Long studentId, Long scholarshipId, String documents) {
        Student student = studentRepository.findById(studentId)
                .orElseThrow(() -> new IllegalArgumentException("Student not found"));
        Scholarship scholarship = scholarshipRepository.findById(scholarshipId)
                .orElseThrow(() -> new IllegalArgumentException("Scholarship not found"));

        Application app = new Application();
        app.setStudent(student);
        app.setScholarship(scholarship);
        app.setApplicationDate(LocalDate.now());
        app.setStatus(ApplicationStatus.PENDING); 
        app.setDocuments(documents);
        return applicationRepository.save(app);
    }

    public List<Application> getAllApplications() {
        return applicationRepository.findAll();
    }

    public Application updateApplicationStatus(Long id, ApplicationStatus status, String comments) {
        Application app = applicationRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Application not found"));

        app.setStatus(status);
        app.setComments(comments);

        return applicationRepository.save(app);
    }

    public List<Application> getApplicationsByStatus(ApplicationStatus status) {
        return applicationRepository.findByStatus(status);
    }

    public Optional<Application> getApplicationById(Long id) {
        return applicationRepository.findById(id);
    }
}