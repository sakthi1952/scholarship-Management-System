package com.examly.springapp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.Optional;
import com.examly.springapp.entity.Student;
import com.examly.springapp.repository.StudentRepository;

@Service
public class StudentService {
    @Autowired
    private StudentRepository studentRepository;

    public List<Student> getAllStudents() {
        return studentRepository.findAll();
    }

    public Optional<Student> getStudentById(Long id) {
        return studentRepository.findById(id);
    }

    // public Student createStudent(Student student) {
    //     return studentRepository.save(student);
    // }
public Student createStudent(Student student) {
        if (student.getEmail() != null) {
                student.setEmail(student.getEmail().trim());
                    }
                        return studentRepository.save(student);
                        }


    public void deleteStudent(Long id) {
        studentRepository.deleteById(id);
    }

    public Student updateStudent(Long id, Student studentDetails) {
        Student student = studentRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Student not found with id: " + id));

        student.setName(studentDetails.getName());
        student.setEmail(studentDetails.getEmail());
        student.setPhoneNumber(studentDetails.getPhoneNumber());
        student.setDepartment(studentDetails.getDepartment());
        student.setYearOfStudy(studentDetails.getYearOfStudy());
        student.setCgpa(studentDetails.getCgpa());
        return studentRepository.save(student);
    }
}
