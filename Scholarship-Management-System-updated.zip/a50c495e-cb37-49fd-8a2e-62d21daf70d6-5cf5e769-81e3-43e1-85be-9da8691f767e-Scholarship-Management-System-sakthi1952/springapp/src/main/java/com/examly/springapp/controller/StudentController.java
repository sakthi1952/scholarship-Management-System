package com.examly.springapp.controller;

import com.examly.springapp.entity.Student;
import com.examly.springapp.service.StudentService;
import java.util.Optional;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/students")
public class StudentController {
  
    @Autowired
    private StudentService studentService;
    @PostMapping
    public ResponseEntity<?> createStudent(@Valid @RequestBody Student student) {
        if (!isValidEmail(student.getEmail())) {
            return new ResponseEntity<>(new ErrorResponse("Invalid email format"), HttpStatus.BAD_REQUEST);
        }
        Student savedStudent = studentService.createStudent(student);
        return new ResponseEntity<>(savedStudent, HttpStatus.CREATED);
    }

    @GetMapping
    public List<Student> getAllStudents() {
        return studentService.getAllStudents();
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getStudentById(@PathVariable Long id) {
        Optional<Student> student = studentService.getStudentById(id);
        if (student.isEmpty()) {
            return new ResponseEntity<>(new ErrorResponse("Student not found"), HttpStatus.NOT_FOUND);
        }
        return ResponseEntity.ok(student.get());
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> updateStudent(@PathVariable Long id, @Valid @RequestBody Student studentDetails) {
        try {
            if (!isValidEmail(studentDetails.getEmail())) {
                return new ResponseEntity<>(new ErrorResponse("Invalid email format"), HttpStatus.BAD_REQUEST);
            }
            Student updatedStudent = studentService.updateStudent(id, studentDetails);
            return ResponseEntity.ok(updatedStudent);
        } catch (RuntimeException e) {
            return new ResponseEntity<>(new ErrorResponse("Student not found"), HttpStatus.NOT_FOUND);
        }
    }
    private boolean isValidEmail(String email) {
        return email != null && email.matches("^\\S+@\\S+\\.\\S+$");
    }

    public static class ErrorResponse {
        private String message;

        public ErrorResponse(String message) {
            this.message = message;
        }

        public String getMessage() {
            return message;
        }
    }
}
//vankkam