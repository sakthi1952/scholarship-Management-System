// import React, { useEffect, useState } from 'react';
// import axios from 'axios';

// const ApplicationList = () => {
//     const [applications, setApplications] = useState([]);
//     const [status, setStatus] = useState('');

//     const fetchApplications = async (statusValue = '') => {
//         try {
//             let url = 'https://8080-fbadcfdbacbbbcaeeccdebdcbcfeeebedafe.premiumproject.examly.io/api/applications';
//             if (statusValue) {
//                 url += `?status=${statusValue}`;
//             }
//             const res = await axios.get(url);
//             setApplications(res.data);
//         } catch (err) {
//             setApplications([]);
//         }
//     };

//     useEffect(() => {
//         fetchApplications();
//     }, []);

//     const handleStatusChange = (e) => {
//         const value = e.target.value;
//         setStatus(value);
//         fetchApplications(value);
//     };

//     return (
//         <div
//             style={{
//                 height: '100vh',
//                 width: '100%',
//                 backgroundImage: 'url("https://images.unsplash.com/photo-1571260899304-425eee4c7efc?q=80&w=1170&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D")',
//                 backgroundSize: 'cover',
//                 backgroundPosition: 'center',
//                 backgroundRepeat: 'no-repeat',
//                 display: 'flex',
//                 justifyContent: 'center',
//                 alignItems: 'flex-start',
//                 paddingTop: '40px'
//             }}
//         >
//             <div
//                 style={{
//                     backgroundColor: 'rgba(0,0,0,0.75)',
//                     padding: '20px',
//                     borderRadius: '8px',
//                     maxWidth: '700px',
//                     width: '100%',
//                     color: 'white'
//                 }}
//             >
//                 <select
//                     data-testid="status-filter"
//                     value={status}
//                     onChange={handleStatusChange}
//                     style={{
//                         padding: '8px',
//                         borderRadius: '5px',
//                         marginBottom: '10px',
//                         width: '100%',
//                         fontSize: '16px'
//                     }}
//                 >
//                     <option value="">All</option>
//                     <option value="PENDING">Pending</option>
//                     <option value="APPROVED">Approved</option>
//                     <option value="REJECTED">Rejected</option>
//                 </select>

//                 {applications.length === 0 ? (
//                     <p>No applications found</p>
//                 ) : (
//                     <ul style={{ listStyle: 'none', padding: 0 }}>
//                         {applications.map((app) => (
//                             <li
//                                 key={app.id}
//                                 style={{
//                                     background: 'rgba(255,255,255,0.1)',
//                                     marginBottom: '8px',
//                                     padding: '10px',
//                                     borderRadius: '6px'
//                                 }}
//                             >
//                                 {app.student.name} applying for {app.scholarship.name}
//                             </li>
//                         ))}
//                     </ul>
//                 )}
//             </div>
//         </div>
//     );
// };

// export default ApplicationList;
import React, { useEffect, useState } from 'react';
import axios from 'axios';

const ApplicationList = () => {
  const [applications, setApplications] = useState([]);
  const [status, setStatus] = useState('');
  const [loading, setLoading] = useState(false);

  const fetchApplications = async (statusValue = '') => {
    try {
      let url =
        'https://8080-cfbfdbbcfcbaeeccdebdcbcfeeebedafe.premiumproject.examly.io/api/applications';
      if (statusValue) {
        url += `?status=${statusValue}`;
      }
      const res = await axios.get(url);
      setApplications(res.data);
    } catch (err) {
      setApplications([]);
    }
  };

  useEffect(() => {
    fetchApplications();
  }, []);

  const handleStatusChange = (e) => {
    const value = e.target.value;
    setStatus(value);
    fetchApplications(value);
  };

  const updateStatus = async (id, newStatus) => {
    try {
      setLoading(true);
      await axios.put(
        `https://8080-cfbfdbbcfcbaeeccdebdcbcfeeebedafe.premiumproject.examly.io/api/applications/${id}/status`,
        { status: newStatus, comments: `${newStatus} by approver` }
      );
      fetchApplications(status); // refresh list
    } catch (err) {
      console.error('Failed to update status', err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div
      style={{
        height: '100vh',
        width: '100%',
        backgroundImage:
          'url("")',
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundRepeat: 'no-repeat',
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'flex-start',
        paddingTop: '40px',
      }}
    >
      <div
        style={{
          backgroundColor: 'rgba(0,0,0,0.75)',
          padding: '20px',
          borderRadius: '8px',
          maxWidth: '700px',
          width: '100%',
          color: 'white',
        }}
      >
        <select
          data-testid="status-filter"
          value={status}
          onChange={handleStatusChange}
          style={{
            padding: '8px',
            borderRadius: '5px',
            marginBottom: '10px',
            width: '100%',
            fontSize: '16px',
          }}
        >
          <option value="">All</option>
          <option value="PENDING">Pending</option>
          <option value="APPROVED">Approved</option>
          <option value="REJECTED">Rejected</option>
        </select>

        {applications.length === 0 ? (
          <p>No applications found</p>
        ) : (
          <ul style={{ listStyle: 'none', padding: 0 }}>
            {applications.map((app) => (
              <li
                key={app.id}
                style={{
                  background: 'rgba(255,255,255,0.1)',
                  marginBottom: '8px',
                  padding: '10px',
                  borderRadius: '6px',
                }}
              >
                <div style={{ marginBottom: '8px' }}>
                  {app.student.name} applying for {app.scholarship.name} —{' '}
                  <strong>Status: {app.status}</strong>
                </div>

                {/* ✅ Approver-only buttons */}
                {app.status === 'PENDING' &&
                  localStorage.getItem('isApprover') === 'true' && (
                    <div>
                      <button
                        onClick={() => updateStatus(app.id, 'APPROVED')}
                        disabled={loading}
                        style={{
                          background: '#10B981',
                          color: 'white',
                          padding: '6px 12px',
                          marginRight: '8px',
                          border: 'none',
                          borderRadius: '4px',
                          cursor: 'pointer',
                        }}
                      >
                        Approve
                      </button>
                      <button
                        onClick={() => updateStatus(app.id, 'REJECTED')}
                        disabled={loading}
                        style={{
                          background: '#EF4444',
                          color: 'white',
                          padding: '6px 12px',
                          border: 'none',
                          borderRadius: '4px',
                          cursor: 'pointer',
                        }}
                      >
                        Reject
                      </button>
                    </div>
                  )}
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
};

export default ApplicationList;
