// // import React from 'react';
// import { Link, useNavigate } from 'react-router-dom';
// import './Navbar.css';

// export default function Navbar() {
//     const navigate = useNavigate();

//     const isAdmin = localStorage.getItem("isAdmin") === "true";
//     const isApprover = localStorage.getItem("isApprover") === "true";

//     const handleLogout = () => {
//         localStorage.clear(); // clear both Admin + Approver session
//         navigate("/"); // go back to Home
//     };

//     return (
//         <nav>
//             <ul>
//                 <li><Link to="/">Home</Link></li>
//                 <li><Link to="/students/register">Register Student</Link></li>
//                 <li><Link to="/scholarships">Scholarships</Link></li>
//                 <li><Link to="/applications">Applications</Link></li>
//                 <li><Link to="/applications/new">Apply</Link></li>

//                 {/* Approver link / logout */}
//                 <li>
//                     {isApprover ? (
//                         <button 
//                             onClick={handleLogout}
//                             style={{
//                                 background: "transparent",
//                                 border: "none",
//                                 color: "white",
//                                 cursor: "pointer",
//                                 fontWeight: "bold"
//                             }}
//                         >
//                             Logout (Approver)
//                         </button>
//                     ) : (
//                         <Link to="/approver">Approver Login</Link>
//                     )}
//                 </li>

//                 {/* Admin link / logout */}
//                 <li>
//                     {isAdmin ? (
//                         <button 
//                             onClick={handleLogout}
//                             style={{
//                                 background: "transparent",
//                                 border: "none",
//                                 color: "white",
//                                 cursor: "pointer",
//                                 fontWeight: "bold"
//                             }}
//                         >
//                             Logout (Admin)
//                         </button>
//                     ) : (
//                         <Link to="/admin/login">Admin Login</Link>
//                     )}
//                 </li>
//             </ul>
//         </nav>
//     );
// }
import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import './Navbar.css';

export default function Navbar() {
    const navigate = useNavigate();

    const isAdmin = localStorage.getItem("isAdmin") === "true";
    const isApprover = localStorage.getItem("isApprover") === "true";

    const handleLogout = () => {
        localStorage.clear(); // clear both Admin + Approver session
        navigate("/"); // go back to Home
    };

    return (
        <nav>
            <ul>
                <li><Link to="/">Home</Link></li>
                <li><Link to="/students/register">Register Student</Link></li>
                <li><Link to="/scholarships">Scholarships</Link></li>
                <li><Link to="/applications">Applications</Link></li>
                <li><Link to="/applications/new">Apply</Link></li>

                {/* Approver link / logout */}
                <li>
                    {isApprover ? (
                        <button 
                            onClick={handleLogout}
                            style={{
                                background: "transparent",
                                border: "none",
                                color: "white",
                                cursor: "pointer",
                                fontWeight: "bold"
                            }}
                        >
                            Logout (Approver)
                        </button>
                    ) : (
                        <Link to="/approver">Approver Login</Link>
                    )}
                </li>

                {/* Admin link / logout */}
                <li>
                    {isAdmin ? (
                        <button 
                            onClick={handleLogout}
                            style={{
                                background: "transparent",
                                border: "none",
                                color: "white",
                                cursor: "pointer",
                                fontWeight: "bold"
                            }}
                        >
                            Logout (Admin)
                        </button>
                    ) : (
                        <Link to="/admin/login">Admin Login</Link>
                    )}
                </li>
            </ul>
        </nav>
    );
}
