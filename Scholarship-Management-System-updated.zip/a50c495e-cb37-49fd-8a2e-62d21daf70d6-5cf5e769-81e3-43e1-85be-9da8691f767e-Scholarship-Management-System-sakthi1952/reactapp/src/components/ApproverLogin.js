// import React, { useState } from "react";
// import { useNavigate } from "react-router-dom";

// export default function ApproverLogin() {
//   const [username, setUsername] = useState("");
//   const [password, setPassword] = useState("");
//   const [error, setError] = useState("");
//   const navigate = useNavigate();

//   const handleLogin = (e) => {
//     e.preventDefault();

//     if (username === "approver" && password === "approver123") {
//       localStorage.setItem("isApprover", "true");
//       navigate("/approver");  // go to Approver dashboard
//     } else {
//       setError("❌ Invalid credentials");
//     }
//   };

//   return (
//     <div style={{ maxWidth: "400px", margin: "50px auto", padding: "24px", background: "white", borderRadius: "8px" }}>
//       <h2>Approver Login</h2>
//       <form onSubmit={handleLogin}>
//         <input
//           type="text"
//           placeholder="Username"
//           value={username}
//           onChange={(e) => setUsername(e.target.value)}
//           style={{ width: "100%", padding: "10px", marginBottom: "12px" }}
//         />
//         <input
//           type="password"
//           placeholder="Password"
//           value={password}
//           onChange={(e) => setPassword(e.target.value)}
//           style={{ width: "100%", padding: "10px", marginBottom: "12px" }}
//         />
//         <button type="submit" style={{ width: "100%", padding: "10px", background: "#2563EB", color: "white", border: "none", borderRadius: "6px" }}>
//           Login
//         </button>
//       </form>
//       {error && <p style={{ color: "red", marginTop: "10px" }}>{error}</p>}
//     </div>
//   );
// }
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

export default function ApproverLogin() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleLogin = (e) => {
    e.preventDefault();

    if (username === "approver" && password === "approver123") {
      localStorage.setItem("isApprover", "true");
      navigate("/approver/dashboard"); // ✅ redirect to dashboard
    } else {
      setError("❌ Invalid credentials");
    }
  };

  return (
    <div
      style={{
        minHeight: "100vh",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        // backgroundImage:
        //   "linear-gradient(rgba(0,0,0,0.6), rgba(0,0,0,0.6)), url('')",
        // backgroundSize: "cover",
        backgroundPosition: "center",
        fontFamily: "Arial, sans-serif",
        padding: "20px",
      }}
    >
      <div
        style={{
          background: "rgba(255,255,255,0.9)",
          padding: "30px",
          borderRadius: "12px",
          maxWidth: "400px",
          width: "100%",
          boxShadow: "0 8px 24px rgba(0,0,0,0.2)",
        }}
      >
        <h2
          style={{
            fontSize: "24px",
            fontWeight: "bold",
            marginBottom: "20px",
            textAlign: "center",
            color: "#222",
          }}
        >
          Approver Login
        </h2>

        <form onSubmit={handleLogin}>
          <div style={{ marginBottom: "15px" }}>
            <input
              type="text"
              placeholder="Username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              required
              style={{
                width: "100%",
                padding: "12px",
                border: "1px solid #ccc",
                borderRadius: "8px",
                fontSize: "16px",
              }}
            />
          </div>

          <div style={{ marginBottom: "15px" }}>
            <input
              type="password"
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              style={{
                width: "100%",
                padding: "12px",
                border: "1px solid #ccc",
                borderRadius: "8px",
                fontSize: "16px",
              }}
            />
          </div>

          <button
            type="submit"
            style={{
              width: "100%",
              padding: "12px",
              backgroundColor: "#2563EB",
              color: "white",
              border: "none",
              borderRadius: "8px",
              fontSize: "16px",
              fontWeight: "bold",
              cursor: "pointer",
              transition: "background 0.3s",
            }}
            onMouseOver={(e) => (e.target.style.backgroundColor = "#1D4ED8")}
            onMouseOut={(e) => (e.target.style.backgroundColor = "#2563EB")}
          >
            Login
          </button>
        </form>

        {error && (
          <p
            style={{
              marginTop: "15px",
              color: "red",
              textAlign: "center",
              fontWeight: "bold",
            }}
          >
            {error}
          </p>
        )}
      </div>
    </div>
  );
}
