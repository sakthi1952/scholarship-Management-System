import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useParams } from 'react-router-dom';

export default function ApplicationDetail() {
    const { id } = useParams();
    const [application, setApplication] = useState(null);
    const [status, setStatus] = useState('');
    const [comments, setComments] = useState('');
    const [message, setMessage] = useState('');
    const [error, setError] = useState('');

    useEffect(() => {
        axios
            .get(`https://8080-cfbfdbbcfcbaeeccdebdcbcfeeebedafe.premiumproject.examly.io/api/applications/${id}/status`)
            .then(res => {
                setApplication(res.data);
                setStatus(res.data.status);
                setComments(res.data.comments || '');
            })
            .catch(() => setError('Failed to load application'));
    }, [id]);

    const updateStatus = () => {
        axios
            .put(`http://localhost:8080/api/applications/${id}/status`, {
                status,
                comments
            })// 
            .then(() => {

                setApplication(prev => ({
                    ...prev,
                    status,
                    comments
                }));
                setMessage('Status updated');
            })
            .catch(() => setMessage('Failed to update'));
    };

    if (error) return <div>{error}</div>;
    if (!application) return <div>Loading...</div>;

    return (
        <div>
            <h2>{application.student.name}</h2>
            <p>Email: {application.student.email}</p>
            <p>Department: {application.student.department}</p>
            <p>CGPA: {application.student.cgpa}</p>

            <label>
                Status:
                <select
                    data-testid="status-select"
                    value={status}
                    onChange={e => setStatus(e.target.value)}
                >
                    <option value="PENDING">PENDING</option>
                    <option value="APPROVED">APPROVED</option>
                    <option value="REJECTED">REJECTED</option>
                </select>
            </label>
            <br />
            <label>
                Comments:
                <input
                    aria-label="Comments"
                    value={comments}
                    onChange={e => setComments(e.target.value)}
                />
            </label>
            <br />
            <button onClick={updateStatus}>Update Status</button>

            {message && <div>{message}</div>}
        </div>
    );
}
