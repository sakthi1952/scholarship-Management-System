# Scholarship Management System


## Documentation
- Updated SRS: `docs/System_Requirements_Specification.md`
- Combined text snapshot: `_READ_ALL_TEXT_FILES.txt`
