package com.examly.springapp.entity;

public enum ApplicationStatus {
PENDING,
APPROVED,
REJECTED

}
