package com.examly.springapp.service;

import java.util.Optional;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.examly.springapp.entity.Scholarship;
import com.examly.springapp.repository.ScholarshipRepository;

@Service
public class ScholarshipService {
    @Autowired
    private ScholarshipRepository scholarshipRepository;

    public List<Scholarship> getAllScholarships() {
        return scholarshipRepository.findAll();
    }

    public List<Scholarship> getScholarshipsByActive(boolean isActive) {
        if (isActive) {
            return scholarshipRepository.findByIsActiveTrue();
        } else {
            return scholarshipRepository.findAll().stream()
                    .filter(s -> !Boolean.TRUE.equals(s.getIsActive()))
                    .toList();
        }
    }

    public Optional<Scholarship> getScholarshipById(Long id) {
        return scholarshipRepository.findById(id);
    }

    public Scholarship createScholarship(Scholarship scholarship) {
        return scholarshipRepository.save(scholarship);
    }

    public Scholarship updateScholarship(Long id, Scholarship updatedScholarship) {
        Scholarship existingScholarship = scholarshipRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Scholarship not found with id: " + id));

        existingScholarship.setName(updatedScholarship.getName());
        existingScholarship.setDescription(updatedScholarship.getDescription());
        existingScholarship.setAmount(updatedScholarship.getAmount());
        existingScholarship.setDeadline(updatedScholarship.getDeadline());
        existingScholarship.setIsActive(updatedScholarship.getIsActive());

        return scholarshipRepository.save(existingScholarship);
    }

}
