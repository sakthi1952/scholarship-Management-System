package com.examly.springapp.controller;

import java.util.Optional;
import com.examly.springapp.entity.Scholarship;
import com.examly.springapp.service.ScholarshipService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import java.util.*;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;
@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/scholarships")
public class ScholarshipController {
    @Autowired
    private ScholarshipService scholarshipService;

    @PostMapping
    public ResponseEntity<?> createScholarship(@RequestBody Scholarship scholarship) {
        try {
            if (!isValidFutureDate(scholarship.getDeadline())) {
                return ResponseEntity.badRequest().body(new ErrorResponse("Deadline must be a future date"));
            }
            Scholarship saved = scholarshipService.createScholarship(scholarship);
            return new ResponseEntity<>(saved, HttpStatus.CREATED);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ErrorResponse("Something went wrong"));
        }
    }

    private boolean isValidFutureDate(LocalDate deadline) {
        return deadline != null && deadline.isAfter(LocalDate.now());
    }

    @GetMapping
    public ResponseEntity<List<Scholarship>> getAllScholarships(@RequestParam(required = false) Boolean active) {
        List<Scholarship> result;
        if (active != null) {
            result = scholarshipService.getScholarshipsByActive(active);
        } else {
            result = scholarshipService.getAllScholarships();
        }
        return ResponseEntity.ok(result);
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getScholarshipById(@PathVariable Long id) {
        Optional<Scholarship> scholarship = scholarshipService.getScholarshipById(id);
        if (scholarship.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(new ErrorResponse("Scholarship not found"));
        }
        return ResponseEntity.ok(scholarship);
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> updateScholarship(@PathVariable Long id, @RequestBody Scholarship scholarship) {
        try {
            Scholarship updated = scholarshipService.updateScholarship(id, scholarship);
            return ResponseEntity.ok(updated);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of("message", e.getMessage()));
        }
    }

    public static class ErrorResponse {
        private String message;

        public ErrorResponse(String message) {
            this.message = message;
        }

        public String getMessage() {
            return message;
        }
    }
}
