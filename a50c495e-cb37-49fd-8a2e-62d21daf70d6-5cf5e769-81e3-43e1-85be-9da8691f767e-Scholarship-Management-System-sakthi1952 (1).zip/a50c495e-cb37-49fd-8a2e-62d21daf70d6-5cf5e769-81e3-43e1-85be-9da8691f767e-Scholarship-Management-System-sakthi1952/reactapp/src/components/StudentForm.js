// import React, { useState } from 'react';
// import axios from 'axios';

// export default function StudentForm() {
//     const [form, setForm] = useState({
//         name: '',
//         email: '',
//         phone: '',
//         department: '',
//         yearOfStudy: '',
//         cgpa: ''
//     });
//     const [errors, setErrors] = useState({});
//     const [message, setMessage] = useState('');

//     const validate = () => {
//         const newErrors = {};
//         if (!form.name) newErrors.name = 'Name is required';
//         if (!form.email) newErrors.email = 'Valid email required';
//         if (!form.phone) newErrors.phone = 'Phone is required';
//         if (!form.department) newErrors.department = 'Department is required';
//         if (!form.yearOfStudy) newErrors.yearOfStudy = 'Year of study is required';
//         if (!form.cgpa) newErrors.cgpa = 'CGPA is required';
//         return newErrors;
//     };

//     const handleChange = (e) => {
//         setForm({ ...form, [e.target.name]: e.target.value });
//     };

//     const handleSubmit = async (e) => {
//         e.preventDefault();
//         setMessage('');
//         const validationErrors = validate();
//         setErrors(validationErrors);
//         if (Object.keys(validationErrors).length > 0) return;

//         const payload = {
//             name: form.name,
//             email: form.email,
//             phoneNumber: form.phone,
//             department: form.department,
//             yearOfStudy: parseInt(form.yearOfStudy, 10),
//             cgpa: parseFloat(form.cgpa)
//         };

//         try {
//             await axios.post(
//                 'https://8080-fbadcfdbacbbbcaeeccdebdcbcfeeebedafe.premiumproject.examly.io/api/students',
//                 payload
//             );
//             setMessage('Student registered successfully');
//             setForm({
//                 name: '',
//                 email: '',
//                 phone: '',
//                 department: '',
//                 yearOfStudy: '',
//                 cgpa: ''
//             });
//         } catch (err) {
//             setMessage(err.response?.data?.message || 'Registration failed');
//         }
//     };

//     return (
//         <div style={{
//             maxWidth: '800px',
//             margin: '0 auto',
//             padding: '24px',
//             backgroundColor: 'white',
//             borderRadius: '8px',
//             boxShadow: '0 4px 6px rgba(0,0,0,0.1)'
//         }}>
//             <h2 style={{
//                 fontSize: '24px',
//                 fontWeight: 'bold',
//                 marginBottom: '24px',
//                 color: '#374151'
//             }}>
//                 Register Student
//             </h2>

//             {message && (
//                 <div style={{
//                     marginBottom: '16px',
//                     padding: '12px',
//                     borderRadius: '6px',
//                     backgroundColor: message.includes('success') ? '#ECFDF5' : '#FEF2F2',
//                     color: message.includes('success') ? '#065F46' : '#991B1B',
//                     border: `1px solid ${message.includes('success') ? '#10B981' : '#EF4444'}`,
//                     fontSize: '14px',
//                     fontWeight: '500'
//                 }}>
//                     {message}
//                 </div>
//             )}

//             <form onSubmit={handleSubmit}>
//                 {[
//                     { id: 'name', label: 'Name', type: 'text', placeholder: 'Name' },
//                     { id: 'email', label: 'Email', type: 'email', placeholder: 'Email' },
//                     { id: 'phone', label: 'Phone Number', type: 'text', placeholder: 'Phone Number' },
//                     { id: 'department', label: 'Department', type: 'text', placeholder: 'Department' },
//                     { id: 'yearOfStudy', label: 'Year of Study', type: 'number', placeholder: 'Year of Study' },
//                     { id: 'cgpa', label: 'CGPA', type: 'number', placeholder: 'CGPA', step: '0.01' }
//                 ].map(field => (
//                     <div key={field.id} style={{ marginBottom: '16px' }}>
//                         <label
//                             htmlFor={field.id}
//                             style={{
//                                 display: 'block',
//                                 fontSize: '14px',
//                                 fontWeight: '500',
//                                 color: '#374151',
//                                 marginBottom: '8px'
//                             }}
//                         >
//                             {field.label}
//                         </label>
//                         <input
//                             id={field.id}
//                             name={field.id}
//                             type={field.type}
//                             step={field.step}
//                             value={form[field.id]}
//                             onChange={handleChange}
//                             placeholder={field.placeholder}
//                             style={{
//                                 width: '100%',
//                                 padding: '8px 12px',
//                                 border: '1px solid #D1D5DB',
//                                 borderRadius: '6px',
//                                 fontSize: '14px'
//                             }}
//                         />
//                         {errors[field.id] && (
//                             <span style={{ color: '#DC2626', fontSize: '12px', marginTop: '4px', display: 'block' }}>
//                                 {errors[field.id]}
//                             </span>
//                         )}
//                     </div>
//                 ))}

//                 <button
//                     type="submit"
//                     style={{
//                         width: '100%',
//                         backgroundColor: '#2563EB',
//                         color: 'white',
//                         padding: '12px 16px',
//                         border: 'none',
//                         borderRadius: '6px',
//                         fontSize: '16px',
//                         cursor: 'pointer',
//                         fontWeight: '500'
//                     }}
//                 >
//                     Register
//                 </button>
//             </form>
//         </div>
//     );
// }






import React, { useState } from 'react';
import axios from 'axios';

export default function StudentForm() {
    const [form, setForm] = useState({
        name: '',
        email: '',
        phone: '',
        department: '',
        yearOfStudy: '',
        cgpa: ''
    });
    const [errors, setErrors] = useState({});
    const [message, setMessage] = useState('');

    const validate = () => {
        const newErrors = {};
        if (!form.name) newErrors.name = 'Name is required';
        if (!form.email) newErrors.email = 'Valid email required';
        if (!form.phone) newErrors.phone = 'Phone is required';
        if (!form.department) newErrors.department = 'Department is required';
        if (!form.yearOfStudy) newErrors.yearOfStudy = 'Year of study is required';
        if (!form.cgpa) newErrors.cgpa = 'CGPA is required';
        return newErrors;
    };

    const handleChange = (e) => {
        setForm({ ...form, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setMessage('');
        const validationErrors = validate();
        setErrors(validationErrors);
        if (Object.keys(validationErrors).length > 0) return;

        const payload = {
            name: form.name,
            email: form.email,
            phoneNumber: form.phone,
            department: form.department,
            yearOfStudy: parseInt(form.yearOfStudy, 10),
            cgpa: parseFloat(form.cgpa)
        };

        try {
            await axios.post(
                'https://8080-cfbfdbbcfcbaeeccdebdcbcfeeebedafe.premiumproject.examly.io/api/students',
                payload
            );
            setMessage('Student registered successfully');
            setForm({
                name: '',
                email: '',
                phone: '',
                department: '',
                yearOfStudy: '',
                cgpa: ''
            });
        } catch (err) {
            setMessage(err.response?.data?.message || 'Registration failed');
        }
    };

    return (
        <div
            style={{
                minHeight: '100vh',
                display: 'flex',
                justifyContent: 'center',
                alignItems: 'center',
                padding: '40px 20px',
                background: 'url("") no-repeat center center/cover',
            }}
        >
            <div
                style={{
                    maxWidth: '800px',
                    width: '100%',
                    padding: '32px',
                    backgroundColor: 'rgba(255, 255, 255, 0.9)',
                    borderRadius: '12px',
                    boxShadow: '0 8px 24px rgba(0,0,0,0.25)',
                    backdropFilter: 'blur(8px)',
                }}
            >
                <h2
                    style={{
                        fontSize: '28px',
                        fontWeight: '700',
                        marginBottom: '24px',
                        textAlign: 'center',
                        color: '#1f2937'
                    }}
                >
                    Register Student
                </h2>

                {message && (
                    <div
                        style={{
                            marginBottom: '20px',
                            padding: '12px',
                            borderRadius: '8px',
                            backgroundColor: message.includes('success') ? '#ECFDF5' : '#FEF2F2',
                            color: message.includes('success') ? '#065F46' : '#991B1B',
                            border: `1px solid ${message.includes('success') ? '#10B981' : '#EF4444'}`,
                            fontSize: '14px',
                            fontWeight: '500',
                            textAlign: 'center',
                        }}
                    >
                        {message}
                    </div>
                )}

                <form onSubmit={handleSubmit}>
                    {[
                        { id: 'name', label: 'Name', type: 'text', placeholder: 'Enter full name' },
                        { id: 'email', label: 'Email', type: 'email', placeholder: 'Enter email address' },
                        { id: 'phone', label: 'Phone Number', type: 'text', placeholder: 'Enter phone number' },
                        { id: 'department', label: 'Department', type: 'text', placeholder: 'Enter department' },
                        { id: 'yearOfStudy', label: 'Year of Study', type: 'number', placeholder: 'e.g. 3' },
                        { id: 'cgpa', label: 'CGPA', type: 'number', placeholder: 'e.g. 8.5', step: '0.01' }
                    ].map(field => (
                        <div key={field.id} style={{ marginBottom: '18px' }}>
                            <label
                                htmlFor={field.id}
                                style={{
                                    display: 'block',
                                    fontSize: '15px',
                                    fontWeight: '600',
                                    color: '#374151',
                                    marginBottom: '8px'
                                }}
                            >
                                {field.label}
                            </label>
                            <input
                                id={field.id}
                                name={field.id}
                                type={field.type}
                                step={field.step}
                                value={form[field.id]}
                                onChange={handleChange}
                                placeholder={field.placeholder}
                                style={{
                                    width: '100%',
                                    padding: '10px 14px',
                                    border: '1px solid #D1D5DB',
                                    borderRadius: '8px',
                                    fontSize: '15px',
                                    transition: 'all 0.3s ease',
                                }}
                                onFocus={(e) => (e.target.style.border = '1px solid #2563EB')}
                                onBlur={(e) => (e.target.style.border = '1px solid #D1D5DB')}
                            />
                            {errors[field.id] && (
                                <span style={{ color: '#DC2626', fontSize: '12px', marginTop: '4px', display: 'block' }}>
                                    {errors[field.id]}
                                </span>
                            )}
                        </div>
                    ))}

                    <button
                        type="submit"
                        style={{
                            width: '100%',
                            backgroundColor: '#2563EB',
                            color: 'white',
                            padding: '14px 18px',
                            border: 'none',
                            borderRadius: '8px',
                            fontSize: '16px',
                            cursor: 'pointer',
                            fontWeight: '600',
                            transition: 'background-color 0.3s ease',
                        }}
                        onMouseOver={(e) => (e.target.style.backgroundColor = '#1E40AF')}
                        onMouseOut={(e) => (e.target.style.backgroundColor = '#2563EB')}
                    >
                        Register
                    </button>
                </form>
            </div>
        </div>
    );
}
