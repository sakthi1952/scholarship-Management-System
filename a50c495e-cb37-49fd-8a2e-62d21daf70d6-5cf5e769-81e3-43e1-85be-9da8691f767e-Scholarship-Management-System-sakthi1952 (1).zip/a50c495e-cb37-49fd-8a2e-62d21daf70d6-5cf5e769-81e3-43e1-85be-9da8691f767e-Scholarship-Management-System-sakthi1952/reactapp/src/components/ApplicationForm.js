// // import React, { useState, useEffect } from "react"
// //   ; export default function ApplicationForm() { const [formData, setFormData] = useState({ studentId: "", scholarshipId: "", documents: "" }); const [students, setStudents] = useState([]); const [scholarships, setScholarships] = useState([]); const [loading, setLoading] = useState(false); const [message, setMessage] = useState(""); useEffect(() => { fetch("https://8080-cfbfdbbcfcbaeeccdebdcbcfeeebedafe.premiumproject.examly.io/api/students").then(res => res.json()).then(data => setStudents(data)).catch(err => console.error("Failed to load students:", err)); fetch("https://8080-cfbfdbbcfcbaeeccdebdcbcfeeebedafe.premiumproject.examly.io/api/scholarships?active=true").then(res => res.json()).then(data => setScholarships(data)).catch(err => console.error("Failed to load scholarships:", err)); }, []); const handleChange = e => { const { name, value } = e.target; setFormData(prev => ({ ...prev, [name]: value })); }; const handleSubmit = async e => { e.preventDefault(); setLoading(true); setMessage(""); try { const applicationData = { studentId: parseInt(formData.studentId), scholarshipId: parseInt(formData.scholarshipId), documents: formData.documents || "No documents provided" }; const response = await fetch("https://8080-cfbfdbbcfcbaeeccdebdcbcfeeebedafe.premiumproject.examly.io/api/applications", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(applicationData) }); if (!response.ok) { const errorData = await response.json(); throw new Error(errorData.message || "Failed to submit application"); } await response.json(); setMessage("Application submitted successfully!"); setFormData({ studentId: "", scholarshipId: "", documents: "" }); } catch (err) { setMessage(err.message); } finally { setLoading(false); } }; return (<div style={{ maxWidth: "600px", margin: "2rem auto", padding: "20px", backgroundColor: "white", borderRadius: "8px", boxShadow: "0 2px 10px rgba(0,0,0,0.1)" }}><h2 style={{ textAlign: "center", color: "#333", marginBottom: "30px" }}>Apply for Scholarship</h2><div><div style={{ marginBottom: "20px" }}><label style={{ display: "block", marginBottom: "8px", fontWeight: "bold", color: "#555" }}>Select Student:</label><select name="studentId" value={formData.studentId} onChange={handleChange} required style={{ width: "100%", padding: "10px", border: "1px solid #ddd", borderRadius: "4px", fontSize: "14px", backgroundColor: "white" }}><option value="">-- Select a Student --</option>{students.map(student => (<option key={student.id} value={student.id}>{student.name} - {student.email} ({student.department})</option>))}</select></div><div style={{ marginBottom: "20px" }}><label style={{ display: "block", marginBottom: "8px", fontWeight: "bold", color: "#555" }}>Select Scholarship:</label><select name="scholarshipId" value={formData.scholarshipId} onChange={handleChange} required style={{ width: "100%", padding: "10px", border: "1px solid #ddd", borderRadius: "4px", fontSize: "14px", backgroundColor: "white" }}><option value="">-- Select a Scholarship --</option>{scholarships.map(scholarship => (<option key={scholarship.id} value={scholarship.id}>{scholarship.name} - ${scholarship.amount}</option>))}</select></div><div style={{ marginBottom: "20px" }}><label style={{ display: "block", marginBottom: "8px", fontWeight: "bold", color: "#555" }}>Documents (optional):</label><textarea name="documents" value={formData.documents} onChange={handleChange} placeholder="Any supporting documents or notes" style={{ width: "100%", padding: "10px", border: "1px solid #ddd", borderRadius: "4px", fontSize: "14px", minHeight: "100px", resize: "vertical" }} /></div><button onClick={handleSubmit} disabled={loading} style={{ width: "100%", backgroundColor: loading ? "#cccccc" : "#4CAF50", color: "white", padding: "12px 24px", border: "none", borderRadius: "4px", cursor: loading ? "not-allowed" : "pointer", fontSize: "16px", fontWeight: "bold" }}>{loading ? "Submitting..." : "Submit Application"}</button></div>{message && (<div style={{ marginTop: "20px", padding: "15px", borderRadius: "4px", backgroundColor: message.includes("success") ? "#d4edda" : "#f8d7da", color: message.includes("success") ? "#155724" : "#721c24", border: `1px solid ${message.includes("success") ? "#c3e6cb" : "#f5c6cb"}` }}>{message}</div>)} {students.length === 0 && (<div style={{ marginTop: "20px", padding: "15px", backgroundColor: "#fff3cd", color: "#856404", borderRadius: "4px", border: "1px solid #ffeaa7" }}><strong>No students found!</strong> Students need to register first before applying for scholarships.</div>)} {scholarships.length === 0 && (<div style={{ marginTop: "20px", padding: "15px", backgroundColor: "#fff3cd", color: "#856404", borderRadius: "4px", border: "1px solid #ffeaa7" }}><strong>No active scholarships found!</strong> Please check back later or contact administration.</div>)}</div >); }
//    import React, { useState, useEffect } from "react";

// export default function ApplicationForm() {
//     const [formData, setFormData] = useState({
//         studentId: "",
//         scholarshipId: "",
//         documents: ""
//     });

//     const [students, setStudents] = useState([]);
//     const [scholarships, setScholarships] = useState([]);
//     const [loading, setLoading] = useState(false);
//     const [message, setMessage] = useState("");

//     useEffect(() => {
//         fetch("https://8080-fbadcfdbacbbbcaeeccdebdcbcfeeebedafe.premiumproject.examly.io/api/students")
//             .then(res => res.json())
//             .then(data => setStudents(data))
//             .catch(err => console.error("Failed to load students:", err));

//         fetch("https://8080-fbadcfdbacbbbcaeeccdebdcbcfeeebedafe.premiumproject.examly.io/api/scholarships?active=true")
//             .then(res => res.json())
//             .then(data => setScholarships(data))
//             .catch(err => console.error("Failed to load scholarships:", err));
//     }, []);

//     const handleChange = e => {
//         const { name, value } = e.target;
//         setFormData(prev => ({ ...prev, [name]: value }));
//     };

//     const handleSubmit = async e => {
//         e.preventDefault();
//         setLoading(true);
//         setMessage("");

//         try {
//             const applicationData = {
//                 studentId: parseInt(formData.studentId),
//                 scholarshipId: parseInt(formData.scholarshipId),
//                 documents: formData.documents || "No documents provided"
//             };

//             const response = await fetch(
//                 "https://8080-fbadcfdbacbbbcaeeccdebdcbcfeeebedafe.premiumproject.examly.io/api/applications",
//                 {
//                     method: "POST",
//                     headers: { "Content-Type": "application/json" },
//                     body: JSON.stringify(applicationData)
//                 }
//             );

//             if (!response.ok) {
//                 const errorData = await response.json();
//                 throw new Error(errorData.message || "Failed to submit application");
//             }

//             await response.json();
//             setMessage("Application submitted successfully!");
//             setFormData({ studentId: "", scholarshipId: "", documents: "" });

//         } catch (err) {
//             setMessage(err.message);
//         } finally {
//             setLoading(false);
//         }
//     };

//     return (
//         <div
//             style={{
//                 maxWidth: "600px",
//                 margin: "2rem auto",
//                 padding: "20px",
//                 backgroundColor: "white",
//                 borderRadius: "8px",
//                 boxShadow: "0 2px 10px rgba(0,0,0,0.1)"
//             }}
//         >
//             <h2 style={{ textAlign: "center", color: "#333", marginBottom: "30px" }}>
//                 Apply for Scholarship
//             </h2>

//             <div>
//                 {/* Student Selection */}
//                 <div style={{ marginBottom: "20px" }}>
//                     <label
//                         style={{
//                             display: "block",
//                             marginBottom: "8px",
//                             fontWeight: "bold",
//                             color: "#555"
//                         }}
//                     >
//                         Select Student:
//                     </label>
//                     <select
//                         name="studentId"
//                         value={formData.studentId}
//                         onChange={handleChange}
//                         required
//                         style={{
//                             width: "100%",
//                             padding: "10px",
//                             border: "1px solid #ddd",
//                             borderRadius: "4px",
//                             fontSize: "14px",
//                             backgroundColor: "white"
//                         }}
//                     >
//                         <option value="">-- Select a Student --</option>
//                         {students.map(student => (
//                             <option key={student.id} value={student.id}>
//                                 {student.name} - {student.email} ({student.department})
//                             </option>
//                         ))}
//                     </select>
//                 </div>

//                 {/* Scholarship Selection */}
//                 <div style={{ marginBottom: "20px" }}>
//                     <label
//                         style={{
//                             display: "block",
//                             marginBottom: "8px",
//                             fontWeight: "bold",
//                             color: "#555"
//                         }}
//                     >
//                         Select Scholarship:
//                     </label>
//                     <select
//                         name="scholarshipId"
//                         value={formData.scholarshipId}
//                         onChange={handleChange}
//                         required
//                         style={{
//                             width: "100%",
//                             padding: "10px",
//                             border: "1px solid #ddd",
//                             borderRadius: "4px",
//                             fontSize: "14px",
//                             backgroundColor: "white"
//                         }}
//                     >
//                         <option value="">-- Select a Scholarship --</option>
//                         {scholarships.map(scholarship => (
//                             <option key={scholarship.id} value={scholarship.id}>
//                                 {scholarship.name} - ${scholarship.amount}
//                             </option>
//                         ))}
//                     </select>
//                 </div>

//                 {/* Documents */}
//                 <div style={{ marginBottom: "20px" }}>
//                     <label
//                         style={{
//                             display: "block",
//                             marginBottom: "8px",
//                             fontWeight: "bold",
//                             color: "#555"
//                         }}
//                     >
//                         Documents (optional):
//                     </label>
//                     <textarea
//                         name="documents"
//                       value={formData.documents}
//                         onChange={handleChange}
//                         placeholder="Any supporting documents or notes"
//                         style={{
//                             width: "100%",
//                             padding: "10px",
//                             border: "1px solid #ddd",
//                             borderRadius: "4px",
//                             fontSize: "14px",
//                             minHeight: "100px",
//                             resize: "vertical"
//                         }}
//                     />
//                 </div>

//                 {/* Submit Button */}
//                 <button
//                     onClick={handleSubmit}
//                     disabled={loading}
//                     style={{
//                         width: "100%",
//                         backgroundColor: loading ? "#cccccc" : "#4CAF50",
//                         color: "white",
//                         padding: "12px 24px",
//                         border: "none",
//                         borderRadius: "4px",
//                         cursor: loading ? "not-allowed" : "pointer",
//                         fontSize: "16px",
//                         fontWeight: "bold"
//                     }}
//                 >
//                     {loading ? "Submitting..." : "Submit Application"}
//                 </button>
//             </div>

//             {/* Message Alert */}
//             {message && (
//                 <div
//                     style={{
//                         marginTop: "20px",
//                         padding: "15px",
//                         borderRadius: "4px",
//                         backgroundColor: message.includes("success")
//                             ? "#d4edda"
//                             : "#f8d7da",
//                         color: message.includes("success") ? "#155724" : "#721c24",
//                         border: `1px solid ${
//                             message.includes("success") ? "#c3e6cb" : "#f5c6cb"
//                         }`
//                     }}
//                 >
//                     {message}
//                 </div>
//             )}

//             {/* No Students Alert */}
//             {students.length === 0 && (
//                 <div
//                     style={{
//                         marginTop: "20px",
//                         padding: "15px",
//                         backgroundColor: "#fff3cd",
//                         color: "#856404",
//                         borderRadius: "4px",
//                         border: "1px solid #ffeaa7"
//                     }}
//                 >
//                     <strong>No students found!</strong> Students need to register first
//                     before applying for scholarships.
//                 </div>
//             )}

//             {/* No Scholarships Alert */}
//             {scholarships.length === 0 && (
//                 <div
//                     style={{
//                         marginTop: "20px",
//                         padding: "15px",
//                         backgroundColor: "#fff3cd",
//                         color: "#856404",
//                         borderRadius: "4px",
//                         border: "1px solid #ffeaa7"
//                     }}
//                 >
//                     <strong>No active scholarships found!</strong> Please check back
//                     later or contact administration.
//                 </div>
//             )}
//         </div>
//     );
// }
import React, { useState, useEffect } from "react";

export default function ApplicationForm() {
    const [formData, setFormData] = useState({
        studentId: "",
        scholarshipId: "",
        documents: ""
    });

    const [students, setStudents] = useState([]);
    const [scholarships, setScholarships] = useState([]);
    const [loading, setLoading] = useState(false);
    const [message, setMessage] = useState("");

    useEffect(() => {
        fetch("https://8080-cfbfdbbcfcbaeeccdebdcbcfeeebedafe.premiumproject.examly.io/api/students")
            .then(res => res.json())
            .then(data => setStudents(data))
            .catch(err => console.error("Failed to load students:", err));

        fetch("https://8080-cfbfdbbcfcbaeeccdebdcbcfeeebedafe.premiumproject.examly.io/api/scholarships?active=true")
            .then(res => res.json())
            .then(data => setScholarships(data))
            .catch(err => console.error("Failed to load scholarships:", err));
    }, []);

    const handleChange = e => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleSubmit = async e => {
        e.preventDefault();
        setLoading(true);
        setMessage("");

        try {
            const applicationData = {
                studentId: parseInt(formData.studentId),
                scholarshipId: parseInt(formData.scholarshipId),
                documents: formData.documents || "No documents provided"
            };

            const response = await fetch(
                "https://8080-cfbfdbbcfcbaeeccdebdcbcfeeebedafe.premiumproject.examly.io/api/applications",
                {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify(applicationData)
                }
            );

            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.message || "Failed to submit application");
            }

            await response.json();
            setMessage("Application submitted successfully!");
            setFormData({ studentId: "", scholarshipId: "", documents: "" });

        } catch (err) {
            setMessage(err.message);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="application-form-page">
      <div className="application-form-container">
        <div
            style={{
                maxWidth: "600px",
                margin: "2rem auto",
                padding: "20px",
                backgroundColor: "white",
                borderRadius: "8px",
                boxShadow: "0 2px 10px rgba(0,0,0,0.1)",
                textAlign: "center"
            }}
        >
            {/* 🎓 Add Image Banner */}
            <img
                src="https://cdn-icons-png.flaticon.com/512/3135/3135755.png"
                alt="Scholarship"
                style={{
                    width: "100px",
                    height: "100px",
                    marginBottom: "15px",
                    objectFit: "contain"
                }}
            />

            <h2 style={{ color: "#333", marginBottom: "30px" }}>
                Apply for Scholarship
            </h2>

            <div>
                {/* Student Selection */}
                <div style={{ marginBottom: "20px", textAlign: "left" }}>
                    <label
                        style={{
                            display: "block",
                            marginBottom: "8px",
                            fontWeight: "bold",
                            color: "#555"
                        }}
                    >
                        Select Student:
                    </label>
                    <select
                        name="studentId"
                        value={formData.studentId}
                        onChange={handleChange}
                        required
                        style={{
                            width: "100%",
                            padding: "10px",
                            border: "1px solid #ddd",
                            borderRadius: "4px",
                            fontSize: "14px",
                            backgroundColor: "white"
                        }}
                    >
                        <option value="">-- Select a Student --</option>
                        {students.map(student => (
                            <option key={student.id} value={student.id}>
                                {student.name} - {student.email} ({student.department})
                            </option>
                        ))}
                    </select>
                </div>

                {/* Scholarship Selection */}
                <div style={{ marginBottom: "20px", textAlign: "left" }}>
                    <label
                        style={{
                            display: "block",
                            marginBottom: "8px",
                            fontWeight: "bold",
                            color: "#555"
                        }}
                    >
                        Select Scholarship:
                    </label>
                    <select
                        name="scholarshipId"
                        value={formData.scholarshipId}
                        onChange={handleChange}
                        required
                        style={{
                            width: "100%",
                            padding: "10px",
                            border: "1px solid #ddd",
                            borderRadius: "4px",
                            fontSize: "14px",
                            backgroundColor: "white"
                        }}
                    >
                        <option value="">-- Select a Scholarship --</option>
                        {scholarships.map(scholarship => (
                            <option key={scholarship.id} value={scholarship.id}>
                                {scholarship.name} - ${scholarship.amount}
                            </option>
                        ))}
                    </select>
                </div>

                {/* Documents */}
                <div style={{ marginBottom: "20px", textAlign: "left" }}>
                    <label
                        style={{
                            display: "block",
                            marginBottom: "8px",
                            fontWeight: "bold",
                            color: "#555"
                        }}
                    >
                        Documents (optional):
                    </label>
                    <textarea
                        name="documents"
                        value={formData.documents}
                        onChange={handleChange}
                        placeholder="Any supporting documents or notes"
                        style={{
                            width: "100%",
                            padding: "10px",
                            border: "1px solid #ddd",
                            borderRadius: "4px",
                            fontSize: "14px",
                            minHeight: "100px",
                            resize: "vertical"
                        }}
                    />
                </div>

                {/* Submit Button */}
                <button
                    onClick={handleSubmit}
                    disabled={loading}
                    style={{
                        width: "100%",
                        backgroundColor: loading ? "#cccccc" : "#4CAF50",
                        color: "white",
                        padding: "12px 24px",
                        border: "none",
                        borderRadius: "4px",
                        cursor: loading ? "not-allowed" : "pointer",
                        fontSize: "16px",
                        fontWeight: "bold"
                    }}
                >
                    {loading ? "Submitting..." : "Submit Application"}
                </button>
            </div>

            {/* Message Alert */}
            {message && (
                <div
                    style={{
                        marginTop: "20px",
                        padding: "15px",
                        borderRadius: "4px",
                        backgroundColor: message.includes("success")
                            ? "#d4edda"
                            : "#f8d7da",
                        color: message.includes("success") ? "#155724" : "#721c24",
                        border: `1px solid ${
                            message.includes("success") ? "#c3e6cb" : "#f5c6cb"
                        }`
                    }}
                >
                    {message}
                </div>
            )}

            {/* No Students Alert */}
            {students.length === 0 && (
                <div
                    style={{
                        marginTop: "20px",
                        padding: "15px",
                        backgroundColor: "#fff3cd",
                        color: "#856404",
                        borderRadius: "4px",
                        border: "1px solid #ffeaa7"
                    }}
                >
                    <strong>No students found!</strong> Students need to register first
                    before applying for scholarships.
                </div>
            )}

            {/* No Scholarships Alert */}
            {scholarships.length === 0 && (
                <div
                    style={{
                        marginTop: "20px",
                        padding: "15px",
                        backgroundColor: "#fff3cd",
                        color: "#856404",
                        borderRadius: "4px",
                        border: "1px solid #ffeaa7"
                    }}
                >
                    <strong>No active scholarships found!</strong> Please check back
                    later or contact administration.
                </div>
            )}
        </div>
        </div>
        </div>
    );
}
