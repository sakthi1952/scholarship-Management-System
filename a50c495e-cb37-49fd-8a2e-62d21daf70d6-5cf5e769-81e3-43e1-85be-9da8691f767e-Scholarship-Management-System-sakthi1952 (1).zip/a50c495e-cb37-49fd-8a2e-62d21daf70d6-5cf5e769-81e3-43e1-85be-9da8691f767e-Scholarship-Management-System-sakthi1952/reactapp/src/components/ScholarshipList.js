import React, { useEffect, useState } from 'react';
import axios from 'axios';

const ScholarshipList = () => {
    const [scholarships, setScholarships] = useState([]);
    const [showActiveOnly, setShowActiveOnly] = useState(false);

    const fetchScholarships = async (activeOnly = false) => {
        try {
            let url = 'https://8080-cfbfdbbcfcbaeeccdebdcbcfeeebedafe.premiumproject.examly.io/api/scholarships';
            if (activeOnly) {
                url += '?active=true';
            }
            const res = await axios.get(url);
            setScholarships(res.data);
        } catch (err) {
            setScholarships([]);
        }
    };

    useEffect(() => {
        fetchScholarships();
    }, []);

    const handleToggle = () => {
        const newValue = !showActiveOnly;
        setShowActiveOnly(newValue);
        fetchScholarships(newValue);
    };

    return (
        <div
            className="scholarship-list-page"
            style={{
                minHeight: '100vh',
                padding: '40px 20px',
                background: 'url("") no-repeat center center/cover',
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
            }}
        >
            <div
                style={{
                    background: 'rgba(255,255,255,0.9)',
                    padding: '30px',
                    borderRadius: '12px',
                    width: '90%',
                    maxWidth: '900px',
                    boxShadow: '0 6px 20px rgba(0,0,0,0.25)',
                    backdropFilter: 'blur(6px)',
                }}
            >
                <h2 style={{ textAlign: 'center', marginBottom: '20px', color: '#1f2937' }}>
                    Available Scholarships
                </h2>

                <div style={{ textAlign: 'center', marginBottom: '20px' }}>
                    <button
                        data-testid="active-toggle"
                        onClick={handleToggle}
                        style={{
                            padding: '10px 20px',
                            backgroundColor: '#2563EB',
                            color: 'white',
                            border: 'none',
                            borderRadius: '6px',
                            fontSize: '15px',
                            cursor: 'pointer',
                            transition: 'all 0.3s ease',
                        }}
                        onMouseOver={(e) => (e.target.style.backgroundColor = '#1E40AF')}
                        onMouseOut={(e) => (e.target.style.backgroundColor = '#2563EB')}
                    >
                        {showActiveOnly ? 'Show All' : 'Show Active'}
                    </button>
                </div>

                {scholarships.length === 0 ? (
                    <p style={{ textAlign: 'center', color: '#6b7280', fontSize: '16px' }}>
                        No scholarships found
                    </p>
                ) : (
                    <ul
                        style={{
                            listStyle: 'none',
                            padding: 0,
                            display: 'grid',
                            gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))',
                            gap: '20px',
                        }}
                    >
                        {scholarships.map((sch) => (
                            <li
                                key={sch.id}
                                style={{
                                    background: 'white',
                                    borderRadius: '10px',
                                    padding: '20px',
                                    boxShadow: '0 4px 10px rgba(0,0,0,0.15)',
                                    transition: 'transform 0.3s ease',
                                }}
                                onMouseOver={(e) => (e.currentTarget.style.transform = 'translateY(-6px)')}
                                onMouseOut={(e) => (e.currentTarget.style.transform = 'translateY(0)')}
                            >
                                <h3 style={{ margin: '0 0 10px', color: '#111827' }}>{sch.name}</h3>
                                <p style={{ margin: '4px 0', color: '#374151' }}>
                                    Amount: <strong>${sch.amount}</strong>
                                </p>
                                <p style={{ margin: '4px 0', color: '#374151' }}>
                                    Deadline: <strong>{sch.deadline}</strong>
                                </p>
                            </li>
                        ))}
                    </ul>
                )}
            </div>
        </div>
    );
};

export default ScholarshipList;
