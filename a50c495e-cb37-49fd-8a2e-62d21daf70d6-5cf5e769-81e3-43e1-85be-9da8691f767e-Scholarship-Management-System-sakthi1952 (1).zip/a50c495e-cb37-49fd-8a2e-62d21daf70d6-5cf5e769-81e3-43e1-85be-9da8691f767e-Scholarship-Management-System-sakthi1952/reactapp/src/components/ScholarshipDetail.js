import React, { useState, useEffect } from "react";
import { useParams, Link } from "react-router-dom";

const ScholarshipDetail = () => {
    const { id } = useParams();
    const [scholarship, setScholarship] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState("");

    useEffect(() => {
        const fetchScholarship = async () => {
            try {
                const res = await fetch(`https://8080-cfbfdbbcfcbaeeccdebdcbcfeeebedafe.premiumproject.examly.io/api/scholarships/${id}`);
                if (!res.ok) throw new Error("Failed to fetch scholarship details");
                const data = await res.json();
                setScholarship(data);
            } catch (err) {
                setError(err.message);
            } finally {
                setLoading(false);
            }
        };

        fetchScholarship();
    }, [id]);

    if (loading) return <p>Loading scholarship details...</p>;
    if (error) return <p style={{ color: "red" }}>{error}</p>;
    if (!scholarship) return <p>No details found for this scholarship.</p>;

    return (
        <div className="form-container" style={{ maxWidth: 600, margin: "2rem auto" }}>
            <h2>{scholarship.name}</h2>
            <p><strong>Description:</strong> {scholarship.description}</p>
            <p><strong>Eligibility:</strong> {scholarship.eligibility}</p>
            <p><strong>Deadline:</strong> {scholarship.deadline}</p>
            <p><strong>Amount:</strong> {scholarship.amount}</p>

            <Link to={`/applications/new?scholarshipId=${scholarship.id}`} className="btn" >
                Apply Now
            </Link>
        </div >
    );
};

export default ScholarshipDetail;