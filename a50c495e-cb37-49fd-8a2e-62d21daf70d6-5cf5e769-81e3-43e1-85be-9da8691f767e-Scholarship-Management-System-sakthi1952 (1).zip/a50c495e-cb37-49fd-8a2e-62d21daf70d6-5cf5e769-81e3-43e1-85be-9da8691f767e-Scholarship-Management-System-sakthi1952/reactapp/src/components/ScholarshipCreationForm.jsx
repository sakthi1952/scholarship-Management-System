// import React, { useState } from 'react';

// export default function ScholarshipCreationForm() {
//     const [formData, setFormData] = useState({
//         name: '',
//         description: '',
//         amount: '',
//         deadline: '',
//         criteria: '',
//         isActive: true
//     });
//     const [loading, setLoading] = useState(false);
//     const [message, setMessage] = useState('');

//     const handleChange = (e) => {
//         const { name, value, type, checked } = e.target;
//         setFormData(prev => ({
//             ...prev,
//             [name]: type === 'checkbox' ? checked : value
//         }));
//     };

//     const handleSubmit = async (e) => {
//         e.preventDefault();
//         setLoading(true);
//         setMessage('');

//         try {
//             const scholarshipData = {
//                 name: formData.name,
//                 description: formData.description,
//                 amount: parseFloat(formData.amount),
//                 deadline: formData.deadline,
//                 criteria: formData.criteria,
//                 isActive: formData.isActive
//             };

//             const response = await fetch("https://8080-fbadcfdbacbbbcaeeccdebdcbcfeeebedafe.premiumproject.examly.io/api/scholarships", {
//                 method: "POST",
//                 headers: {
//                     'Content-Type': 'application/json'
//                 },
//                 body: JSON.stringify(scholarshipData)
//             });

//             if (!response.ok) {
//                 throw new Error('Failed to create scholarship');
//             }

//             const result = await response.json();
//             setMessage('Scholarship created successfully!');
            
//             // Reset form
//             setFormData({
//                 name: '',
//                 description: '',
//                 amount: '',
//                 deadline: '',
//                 criteria: '',
//                 isActive: true
//             });

//         } catch (error) {
//             setMessage(error.message || 'Failed to create scholarship');
//         } finally {
//             setLoading(false);
//         }
//     };

//     return (
//         <div style={{ maxWidth: '800px', margin: '0 auto', padding: '24px', backgroundColor: 'white', borderRadius: '8px', boxShadow: '0 4px 6px rgba(0,0,0,0.1)' }}>
//             <h2 style={{ fontSize: '24px', fontWeight: 'bold', marginBottom: '24px', color: '#374151' }}>Create New Scholarship</h2>
            
//             <div>
//                 <div style={{ marginBottom: '16px' }}>
//                     <label style={{ display: 'block', fontSize: '14px', fontWeight: '500', color: '#374151', marginBottom: '8px' }}>
//                         Scholarship Name
//                     </label>
//                     <input
//                         type="text"
//                         name="name"
//                         value={formData.name}
//                         onChange={handleChange}
//                         required
//                         style={{ width: '100%', padding: '8px 12px', border: '1px solid #D1D5DB', borderRadius: '6px', fontSize: '14px' }}
//                         placeholder="e.g., Merit Scholarship 2024"
//                     />
//                 </div>

//                 <div style={{ marginBottom: '16px' }}>
//                     <label style={{ display: 'block', fontSize: '14px', fontWeight: '500', color: '#374151', marginBottom: '8px' }}>
//                         Description
//                     </label>
//                     <textarea
//                         name="description"
//                         value={formData.description}
//                         onChange={handleChange}
//                         required
//                         rows="4"
//                         style={{ width: '100%', padding: '8px 12px', border: '1px solid #D1D5DB', borderRadius: '6px', fontSize: '14px', resize: 'vertical' }}
//                         placeholder="Describe the scholarship purpose and benefits..."
//                     />
//                 </div>

//                 <div style={{ marginBottom: '16px' }}>
//                     <label style={{ display: 'block', fontSize: '14px', fontWeight: '500', color: '#374151', marginBottom: '8px' }}>
//                         Amount ($)
//                     </label>
//                     <input
//                         type="number"
//                         name="amount"
//                         value={formData.amount}
//                         onChange={handleChange}
//                         required
//                         min="0"
//                         step="0.01"
//                         style={{ width: '100%', padding: '8px 12px', border: '1px solid #D1D5DB', borderRadius: '6px', fontSize: '14px' }}
//                         placeholder="5000.00"
//                     />
//                 </div>

//                 <div style={{ marginBottom: '16px' }}>
//                     <label style={{ display: 'block', fontSize: '14px', fontWeight: '500', color: '#374151', marginBottom: '8px' }}>
//                         Application Deadline
//                     </label>
//                     <input
//                         type="date"
//                         name="deadline"
//                         value={formData.deadline}
//                         onChange={handleChange}
//                         required
//                         style={{ width: '100%', padding: '8px 12px', border: '1px solid #D1D5DB', borderRadius: '6px', fontSize: '14px' }}
//                     />
//                 </div>

//                 <div style={{ marginBottom: '16px' }}>
//                     <label style={{ display: 'block', fontSize: '14px', fontWeight: '500', color: '#374151', marginBottom: '8px' }}>
//                         Eligibility Criteria
//                     </label>
//                     <textarea
//                         name="criteria"
//                         value={formData.criteria}
//                         onChange={handleChange}
//                         required
//                         rows="3"
//                         style={{ width: '100%', padding: '8px 12px', border: '1px solid #D1D5DB', borderRadius: '6px', fontSize: '14px', resize: 'vertical' }}
//                         placeholder="e.g., Minimum CGPA 3.5, Engineering students only..."
//                     />
//                 </div>

//                 <div style={{ marginBottom: '16px', display: 'flex', alignItems: 'center' }}>
//                     <input
//                         type="checkbox"
//                         name="isActive"
//                         checked={formData.isActive}
//                         onChange={handleChange}
//                         style={{ marginRight: '8px' }}
//                     />
//                     <label style={{ fontSize: '14px', color: '#374151' }}>
//                         Active (students can apply)
//                     </label>
//                 </div>

//                 <button
//                     onClick={handleSubmit}
//                     disabled={loading}
//                     style={{
//                         width: '100%',
//                         backgroundColor: loading ? '#9CA3AF' : '#2563EB',
//                         color: 'white',
//                         padding: '12px 16px',
//                         border: 'none',
//                         borderRadius: '6px',
//                         fontSize: '16px',
//                         cursor: loading ? 'not-allowed' : 'pointer',
//                         fontWeight: '500'
//                     }}
//                 >
//                     {loading ? 'Creating Scholarship...' : 'Create Scholarship'}
//                 </button>
//             </div>

//             {message && (
//                 <div style={{
//                     marginTop: '16px',
//                     padding: '12px',
//                     borderRadius: '6px',
//                     backgroundColor: message.includes('success') ? '#ECFDF5' : '#FEF2F2',
//                     color: message.includes('success') ? '#065F46' : '#991B1B',
//                     border: `1px solid ${message.includes('success') ? '#10B981' : '#EF4444'}`
//                 }}>
//                     {message}
//                 </div>
//             )}
//         </div>
//     );
// }
import React, { useState } from 'react';
import '../App.css';

export default function ScholarshipCreationForm() {
    const [formData, setFormData] = useState({
        name: '',
        description: '',
        amount: '',
        deadline: '',
        criteria: '',
        isActive: true
    });
    const [loading, setLoading] = useState(false);
    const [message, setMessage] = useState('');

    const handleChange = (e) => {
        const { name, value, type, checked } = e.target;
        setFormData(prev => ({
            ...prev,
            [name]: type === 'checkbox' ? checked : value
        }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);
        setMessage('');

        try {
            const scholarshipData = {
                name: formData.name,
                description: formData.description,
                amount: parseFloat(formData.amount),
                deadline: formData.deadline,
                criteria: formData.criteria,
                isActive: formData.isActive
            };

            const response = await fetch("https://8080-cfbfdbbcfcbaeeccdebdcbcfeeebedafe.premiumproject.examly.io/api/scholarships", {
                method: "POST",
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(scholarshipData)
            });

            if (!response.ok) {
                throw new Error('Failed to create scholarship');
            }

            await response.json();
            setMessage('Scholarship created successfully!');

            // Reset form
            setFormData({
                name: '',
                description: '',
                amount: '',
                deadline: '',
                criteria: '',
                isActive: true
            });

        } catch (error) {
            setMessage(error.message || 'Failed to create scholarship');
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="page-container scholarship-create-page">
            <div className="form-container">
                <h2>Create New Scholarship</h2>

                <form onSubmit={handleSubmit}>
                    <div>
                        <label>Scholarship Name</label>
                        <input
                            type="text"
                            name="name"
                            value={formData.name}
                            onChange={handleChange}
                            required
                            placeholder="e.g., Merit Scholarship 2024"
                        />
                    </div>

                    <div>
                        <label>Description</label>
                        <textarea
                            name="description"
                            value={formData.description}
                            onChange={handleChange}
                            required
                            rows="4"
                            placeholder="Describe the scholarship purpose and benefits..."
                        />
                    </div>

                    <div>
                        <label>Amount ($)</label>
                        <input
                            type="number"
                            name="amount"
                            value={formData.amount}
                            onChange={handleChange}
                            required
                            min="0"
                            step="0.01"
                            placeholder="5000.00"
                        />
                    </div>

                    <div>
                        <label>Application Deadline</label>
                        <input
                            type="date"
                            name="deadline"
                            value={formData.deadline}
                            onChange={handleChange}
                            required
                        />
                    </div>

                    <div>
                        <label>Eligibility Criteria</label>
                        <textarea
                            name="criteria"
                            value={formData.criteria}
                            onChange={handleChange}
                            required
                            rows="3"
                            placeholder="e.g., Minimum CGPA 3.5, Engineering students only..."
                        />
                    </div>

                    <div style={{ display: 'flex', alignItems: 'center' }}>
                        <input
                            type="checkbox"
                            name="isActive"
                            checked={formData.isActive}
                            onChange={handleChange}
                            style={{ marginRight: '8px' }}
                        />
                        <label>Active (students can apply)</label>
                    </div>

                    <button type="submit" disabled={loading}>
                        {loading ? 'Creating Scholarship...' : 'Create Scholarship'}
                    </button>
                </form>

                {message && (
                    <div className={message.includes('success') ? 'success' : 'error'}>
                        {message}
                    </div>
                )}
            </div>
        </div>
    );
}
