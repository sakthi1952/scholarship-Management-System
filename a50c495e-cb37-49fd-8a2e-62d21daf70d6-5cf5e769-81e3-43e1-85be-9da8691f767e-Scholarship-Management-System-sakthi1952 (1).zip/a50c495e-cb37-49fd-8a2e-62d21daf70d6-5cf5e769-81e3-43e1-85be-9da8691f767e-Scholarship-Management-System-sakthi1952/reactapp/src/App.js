// import React from 'react';
// import {
//   BrowserRouter as Router,
//   Routes,
//   Route
// } from 'react-router-dom';
// import Navbar from './components/Navbar';
// import StudentForm from './components/StudentForm';
// import ScholarshipList from './components/ScholarshipList';
// import ScholarshipDetail from './components/ScholarshipDetail';
// import ApplicationForm from './components/ApplicationForm';
// import ApplicationList from './components/ApplicationList';
// import ApplicationDetail from './components/ApplicationDetail';
// import ScholarshipCreationForm from './components/ScholarshipCreationForm';
// import AdminLogin from './components/AdminLogin';
// import './App.css';
// import ApproverLogin from "./components/ApproverLogin";

// // ✅ Home wrapped with background class
// const Home = () => (
//   <div className="page-container home-page">
//     <div style={{ background: "rgba(255,255,255,0.8)", padding: "2rem", borderRadius: "8px", maxWidth: 600 }}>
//       <h2>Welcome to Scholarship Management System</h2>
//       <center><p>Apply for scholarships and track your applications.</p></center>
//     </div>
//   </div>
// );

// function App() {
//   return (
//     <Router>
//       <Navbar />
//       <Routes>
//         <Route path="/" element={<Home />} />
//         <Route path="/students/register" element={<StudentForm />} />
//         <Route path="/scholarships" element={<ScholarshipList />} />
//         <Route path="/scholarships/:id" element={<ScholarshipDetail />} />
//         <Route path="/applications" element={<ApplicationList />} />
//         <Route path="/applications/new" element={<ApplicationForm />} />
//         <Route path="/applications/:id" element={<ApplicationDetail />} />
//          <Route path="/approver" element={<ApproverLogin />} />
//         <Route path="/admin/login" element={<AdminLogin />} />
        
//         <Route path="/create-scholarship" element={<ScholarshipCreationForm />} />
//       </Routes>
//     </Router>
//   );
// }

// export default App;
import React from 'react';
import {
  BrowserRouter as Router,
  Routes,
  Route,
  Navigate
} from 'react-router-dom';
import Navbar from './components/Navbar';
import StudentForm from './components/StudentForm';
import ScholarshipList from './components/ScholarshipList';
import ScholarshipDetail from './components/ScholarshipDetail';
import ApplicationForm from './components/ApplicationForm';
import ApplicationList from './components/ApplicationList';
import ApplicationDetail from './components/ApplicationDetail';
import ScholarshipCreationForm from './components/ScholarshipCreationForm';
import AdminLogin from './components/AdminLogin';
import ApproverLogin from "./components/ApproverLogin";
import './App.css';

// ✅ Home wrapped with background class
const Home = () => (
  <div className="page-container home-page">
    <div style={{ background: "rgba(255,255,255,0.8)", padding: "2rem", borderRadius: "8px", maxWidth: 600 }}>
      <h2>Welcome to Scholarship Management System</h2>
      <center><p>Apply for scholarships and track your applications.</p></center>
    </div>
  </div>
);

// ✅ Protected Routes
const AdminRoute = ({ children }) => {
  return localStorage.getItem("isAdmin") === "true" ? children : <Navigate to="/admin/login" />;
};

const ApproverRoute = ({ children }) => {
  return localStorage.getItem("isApprover") === "true" ? children : <Navigate to="/approver" />;
};

function App() {
  return (
    <Router>
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/students/register" element={<StudentForm />} />
        <Route path="/scholarships" element={<ScholarshipList />} />
        <Route path="/scholarships/:id" element={<ScholarshipDetail />} />
        <Route path="/applications" element={<ApplicationList />} />
        <Route path="/applications/new" element={<ApplicationForm />} />
        <Route path="/applications/:id" element={<ApplicationDetail />} />

        {/* Approver login + protected route */}
        <Route path="/approver" element={<ApproverLogin />} />
        <Route
          path="/approver/dashboard"
          element={
            <ApproverRoute>
              <ApplicationList />
            </ApproverRoute>
          }
        />

        {/* Admin login + protected route */}
        <Route path="/admin/login" element={<AdminLogin />} />
        <Route
          path="/create-scholarship"
          element={
            <AdminRoute>
              <ScholarshipCreationForm />
            </AdminRoute>
          }
        />
      </Routes>
    </Router>
  );
}

export default App;
