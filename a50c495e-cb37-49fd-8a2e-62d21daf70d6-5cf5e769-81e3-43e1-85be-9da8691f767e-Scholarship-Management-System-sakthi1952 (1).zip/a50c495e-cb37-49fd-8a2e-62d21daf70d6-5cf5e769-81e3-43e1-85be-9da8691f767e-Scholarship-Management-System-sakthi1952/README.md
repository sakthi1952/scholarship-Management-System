# f02a42bd-cdad-4f8a-ab6d-66fb99128e50-5cf5e769-81e3-43e1-85be-9da8691f767e
Repository for Teams Project code and project management
